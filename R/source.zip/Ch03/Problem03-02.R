year_born <- 2002     # 자신이 태어난 연도를 저장
current_year <- 2021  # 현재 연도를 저장
age <- current_year - year_born + 1
print(age)