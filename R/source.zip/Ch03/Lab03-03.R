str <- paste('good', 'morning', sep=' / ')
str

a <- '나의 나이는'
b <- 20
c <- '입니다'
paste(a, b, c, sep=' ')

a <- 1:12
b <- '월'
c <- paste(a, b, sep='')
c