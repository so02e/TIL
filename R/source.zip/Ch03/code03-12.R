absent <- c(8,2,0,4,1)          # absent 벡터에 결근 인원수 저장
absent                          # absent 벡터의 내용 출력 
names(absent)                   # absent 벡터의 값들의 이름을 확인
names(absent) <- c('Mon','Tue','Wed','Thu','Fri')    # 값들의 이름을 입력
absent                          # absent 벡터의 내용 출력 
names(absent)                   # absent 벡터의 값들의 이름을 확인