return <- c(4, 11, 5, 3, 2)
names(return) <- c('shoes', 'shirt', 'pants', 'scarf', 'belt')