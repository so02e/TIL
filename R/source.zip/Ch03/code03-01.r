total <- 5050                  # 5050을 변수 total에 저장
total                          # 방법 1   
print(total)                   # 방법 2
cat('합계 :', total)           # 방법 3
