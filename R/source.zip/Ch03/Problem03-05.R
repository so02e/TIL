shop.name <- "R-mart"
sales.today <- 530
sales.yesterday <- 440
increase <- sales.today > sales.yesterday