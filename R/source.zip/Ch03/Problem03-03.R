input <- 13; output <- 29; times <- 5
input <- input * times
print(input)   # (1)
input <- input - output
print(input)   # (2)