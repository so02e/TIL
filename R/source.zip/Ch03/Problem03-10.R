play <- c(421, 298, 254, 232, 239, 368, 465)
names(play) <- c('sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat')

# 정답
play[c('tue', 'thu')] <- c(267, 241)