salt <- 50
water <- 100
result <- salt / (salt + water) *100
cat("소금 =", salt, ", 물 =", water, " : 결과 =", result, "%")

salt <- 70
water <- 110
result <- salt / (salt + water) *100
cat("소금 =", salt, ", 물 =", water, " : 결과 =", result, "%")