age.1 <- 20                      # 숫자 저장
age.2 <- 25                      # 숫자 저장   
print(age.1 + age.2)             # 정상 실행
name.1 <- 'John'                 # 문자 저장
print(name.1)                                       
grade.1 <- '3'                   # 문자 저장
print(age.1 + grade.1)           # 에러 발생