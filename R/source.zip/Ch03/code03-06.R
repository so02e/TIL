addr <- NULL                     # NULL 저장
print(addr)