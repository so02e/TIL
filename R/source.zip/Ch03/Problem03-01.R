age <- 20    # 자신의 나이를 저장
print(age)