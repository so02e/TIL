score.1 <- 68; score.2 <- 95; score.3 <- 83; score.4 <- 76; score.5 <- 90
score.6 <- 80; score.7 <- 85; score.8 <- 91; score.9 <- 82; score.10 <- 70
total <- score.1 + score.2 + score.3 + score.4 + score.5 +
  score.6 + score.7 + score.8 + score.9 + score.10 
avg <- total / 10             # 10명의 평균 계산
avg                           # 평균 출력