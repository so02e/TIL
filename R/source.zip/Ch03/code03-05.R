5 > 3                            # 비교연산  
2 > 7                            # 비교연산
TRUE + TRUE                      # 산술연산에서 TRUE는 1   
a <- TRUE                        # a에 논리값 TRUE 저장
b <- F                           # b에 논리값 FALSE 저장

a                                # a의 내용 출력
b                                # b의 내용 출력
a + b                            # 논리값의 산술연산 결과