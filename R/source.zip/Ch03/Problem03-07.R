# (1)
v <- rep(c('a', 'b', 'c'), times = 3)
v

# (2)
v <- rep(c('a', 'b', 'c'), each = 3)
v