install.packages("DAAG")
library(DAAG)

plot(milk$four, milk$one)
# 또는
plot(milk)