# [코드 9-6] 에 이어서      
boxplot.stats(dist)
