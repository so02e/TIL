install.packages("DAAG")
library(DAAG)

plot(codling[,c('dose','pobs','ct')])