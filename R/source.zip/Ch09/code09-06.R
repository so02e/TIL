dist <- cars[,2]                      # 자동차 제동거리 (단위: 피트)
boxplot(dist, main='자동차 제동거리')