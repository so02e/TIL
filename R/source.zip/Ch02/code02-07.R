# ggplot2 패키지 설치 
install.packages('ggplot2')