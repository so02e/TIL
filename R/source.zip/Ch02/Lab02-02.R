install.packages('cowsay')

library(cowsay)

say('Hello world!', by='cat')

say('좋은 아침', by = 'snowman')