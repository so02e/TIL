print(B)
