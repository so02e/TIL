# ggplot2 불러오기 
library(ggplot2)