hist(trees$Girth, 
     main =  '체리나무 지름에 대한 히스토그램' ,
     xlab = '지름',
     ylab = '빈도수',
     border = 'red',
     col = 'orange',
     las = 1,
     breaks = 4)