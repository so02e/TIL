# [코드 8-5]에 이어서 실행

barplot(ds, main='favorite season', 
        col='yellow',                          # 막대의 색을 지정
        horiz=TRUE)                            # 세로 방향 출력    