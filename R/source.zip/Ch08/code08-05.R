# [코드 8-4]에 이어서 실행

barplot(ds, main='favorite season', 
        col='green',                           # 막대의 색을 지정
        xlab='계절',                           # x축 설명
        ylab='빈도수' )                        # y축 설명