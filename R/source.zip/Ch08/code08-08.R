# [코드 8-7]에 이어서 실행

barplot(ds, main='favorite season', 
        col='green',                          # 막대의 색을 지정
        las=2)                                # 그룹 이름을 수직 방향으로    