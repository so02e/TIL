# [코드 8-6]에 이어서 실행

barplot(ds, main='favorite season', 
        col='yellow',                          # 막대의 색을 지정
        names=c('FA','SP','SU','WI'))          # 그룹 이름을 바꾸어 출력    