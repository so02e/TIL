# [코드 8-2]에 이어서 실행

barplot(ds, main='favorite season', 
        col='blue')                   # 막대의 색 지정