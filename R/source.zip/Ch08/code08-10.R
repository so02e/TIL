# 코드 8-9에 이어서 실행

barplot(ds, main='인구 추정', 
        col=c('green','blue','yellow'))