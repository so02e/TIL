myprint <- function(name = '아무개'){
  cat('내 이름은 [', name, ']입니다. \n')
}
myprint()
myprint('홍길동')         # 자신의 이름 입력