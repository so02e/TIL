for(i in 6:10) {
  print(i)
}