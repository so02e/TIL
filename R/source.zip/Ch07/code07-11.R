sum <- 0
i <- 1
while(i <=100) {
  sum <- sum + i             # sum 에 i 값을 누적
  i <- i + 1                 # i 값을 1 증가시킴
}
print(sum)