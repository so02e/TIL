weather <- '맑음'                               # 이 값을 변경하여 결과 비교
choice <- ifelse(weather == '비', '우산', '모자')
print(choice)