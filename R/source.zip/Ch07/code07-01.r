job.type <- 'A'
if (job.type == 'B') {
  bonus <- 200            # 직군이 B일 때 실행
} else {
  bonus <- 100            # 직군이 B가 아닌 나머지 경우 실행 
}
print(bonus)