apply(USJudgeRatings, 1, mean)  # 행별 평균
apply(USJudgeRatings, 2, mean)  # 열별 평균