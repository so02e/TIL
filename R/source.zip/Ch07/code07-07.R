for(i in 1:9) {
  cat('2 *', i,'=', 2*i,'\n') 
}