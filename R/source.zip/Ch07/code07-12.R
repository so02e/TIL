apply(iris[,1:4], 1, mean)    # 행 방향으로 함수 적용
apply(iris[,1:4], 2, mean)    # 열 방향으로 함수 적용