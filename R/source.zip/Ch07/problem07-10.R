setwd('c:/Rworks')
source('myfunc.R')
mysum(20)