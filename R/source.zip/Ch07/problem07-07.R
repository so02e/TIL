mysum <- function(n){
  return(sum(1:n))
}
mysum(100)