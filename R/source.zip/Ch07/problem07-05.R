i <- 1
result <- 1

while(i <= 10){
  result <- result * 2
  i <- i + 1
}

print(result)
