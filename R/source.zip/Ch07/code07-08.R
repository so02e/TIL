for(i in 1:20) {
  if(i%%2==0) {          # 짝수인지 확인
    print(i)
  }
}