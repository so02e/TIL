getwd()                    # 현재 작업 폴더 알아내기
setwd('C:/Rworks')         # 작업 폴더를 변경하기 
getwd()                    