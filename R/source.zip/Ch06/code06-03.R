x <- 26
y <- '입니다'
z <- c(10,20,30,40)
print(x)                   # 하나의 값 출력
print(y)                   # 하나의 값 출력
print(z)                   # 벡터 출력
print(iris[1:5,])          # 데이터프레임 출력
print(x,y)                 # 에러 발생