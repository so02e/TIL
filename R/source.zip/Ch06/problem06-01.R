name <- '가나다'
cat('제 이름 은', name, '입니다= "")