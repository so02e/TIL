boxplot(Temp~Month, data=airquality,  
        ylab='기온',
        xlab='월',
        main='월별 기온')