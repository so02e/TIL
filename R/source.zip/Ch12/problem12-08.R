ggplot(data=cars, aes(y=dist)) + 
  geom_boxplot(fill='red') 