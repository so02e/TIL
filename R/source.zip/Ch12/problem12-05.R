radarchart(ds, 
           pfcol=rgb(0.1,0.4,0.4,0.5),
           pcol='steelblue'
) 