city <- c("Seoul","Tokyo","Washington")   # 문자로 이루어진 벡터
rank <- c(1,3,2)                          # 숫자로 이루어진 벡터
city.info <- data.frame(city, rank)       # 데이터프레임 생성
city.info                                 # city.info의 내용 출력