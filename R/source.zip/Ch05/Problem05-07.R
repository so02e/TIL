# (1) 
head(sleep, n=10)

# (2) 
tail(sleep, n=8)

# (3) 
dim(sleep)

# (4) 
nrow(sleep); ncol(sleep)

# (5) 
colnames(sleep)

# (6) 
str(sleep)

# (7) 
levels(sleep[ ,'group'])

# (8) 
table(sleep[ ,'group'])