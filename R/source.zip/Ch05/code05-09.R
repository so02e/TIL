dim(iris)         # 행과 열의 개수 보이기
nrow(iris)        # 행의 개수 보이기
ncol(iris)        # 열의 개수 보이기
colnames(iris)    # 열 이름 보이기, names() 함수와 결과 동일
head(iris)        # 데이터셋의 앞부분 일부 보기
tail(iris)        # 데이터셋의 뒷부분 일부 보기