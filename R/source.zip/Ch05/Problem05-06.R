# (1)
iris[1:10, -5] 
iris[1:10, 1:4]

# (2)
iris[1:10, c('Sepal.Length','Sepal.Width','Petal.Length','Petal.Width')]
