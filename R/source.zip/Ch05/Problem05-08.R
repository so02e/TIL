# (1) 
colSums(mtcars); colMeans(mtcars)

# (2) 
rowSums(mtcars); rowMeans(mtcars)

# (3) 
subset(mtcars, hp >= 100 & hp < 200)
 
# (4) 
0.9 * mtcars[ ,1:3] + 1