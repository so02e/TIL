# (1) 
class(mtcars)

# (2) 
is.matrix(mtcars)

# (3) 
is.data.frame(mtcars)

# (4) 
mtcars.m <- as.matrix(mtcars)

# (5) 
is.matrix(mtcars.m)