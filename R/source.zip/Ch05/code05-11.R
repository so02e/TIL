colSums(iris[,-5])        # 열별 합계
colMeans(iris[,-5])       # 열별 평균
rowSums(iris[,-5])        # 행별 합계
rowMeans(iris[,-5])       # 행별 평균