class(iris)               # iris 데이터셋의 자료구조 확인
class(state.x77)          # state.x77 데이터셋의 자료구조 확인
is.matrix(iris)           # 데이터셋이 매트릭스인지 확인하는 함수
is.data.frame(iris)       # 데이터셋이 데이터프레임인지 확인하는 함수tate.x77)
is.data.frame(state.x77)