# 히스토그램
hist(TitanicSurvival$age, main='탑승자 연령대',
     xlab='연령대',
     ylab='탐승자수') 

# 상자그림
boxplot(TitanicSurvival$age, main='탑승자 연령대')