korea <- subset(ds, country=='South Korea')
korea[,c('rank','name','category','marketvalue')]