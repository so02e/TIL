install.packages("HSAUR")

library(HSAUR)
data("Forbes2000")
ds <- Forbes2000 
ds[!complete.cases(ds),]          # 결측값 확인