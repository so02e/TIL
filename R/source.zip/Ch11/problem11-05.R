idx <- sample(nrow(state.x77), size=10, replace=F)
state.10 <- state.x77[idx,]      # 10개의 행 추출
state.10