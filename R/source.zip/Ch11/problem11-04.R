state.x77[order(state.x77[,'Population'], decreasing = T),]
