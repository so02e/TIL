x <- 1:100
y <- sample(x, size=10, replace=FALSE)    # 비복원 추출
y