v1 <- c(1,7,6,8,4,2,3)
v1 <- sort(v1)                  # 오름차순
v1
v2 <- sort(v1, decreasing=T)    # 내림차순 
v2