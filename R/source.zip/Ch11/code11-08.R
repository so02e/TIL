name <- c('정대일','강재구','신현석','홍길동')
sort(name)                      # 오름차순
sort(name, decreasing=T)        # 내림차순 