sp <- levels(iris$Species)
combn(sp, 2)