a <- seq(from = 20, to = 80, by = 7)

length(a)                     # (1)
sort(a, decreasing = T)       # (2)
max(a); min(a); range(a)      # (3)
mean(a); median(a)            # (4)
var(a); sd(a)                 # (5)