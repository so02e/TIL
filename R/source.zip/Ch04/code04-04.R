v1 <- c(1, 2, 3, 4)
v2 <- c('John', 'Jane', 'Tom')
v3 <- c(v1, v2)  # v1, v2의 원소들을 결합하여 v3에 저장
v3