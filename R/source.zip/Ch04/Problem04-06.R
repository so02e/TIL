a <- c('red', 'white', 'brown', 'green', 'white', 'red', 'brown', 'white')

b <- factor(a)    # (1)
levels(b)         # (2)
as.integer(b)     # (3)