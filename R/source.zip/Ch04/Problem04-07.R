# (1)
oneday_class = list(class='sun_catcher', 
                    day=c('Tue','Wed','Sat'), 
                    price = 60000, 
                    parking = TRUE)  

# (2)
oneday_class[[2]] 

#
oneday_class$price 